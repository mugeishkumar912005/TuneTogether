const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();

// Define a route to stream songs
app.get('/stream/:filename', (req, res) => {
  const fileName = req.params.filename;
  const filePath = path.join(__dirname, 'songs', fileName);

  // Check if the file exists
  fs.access(filePath, fs.constants.R_OK, (err) => {
    if (err) {
      console.error(err);
      return res.status(404).send('File not found');
    }

    // Create a read stream from the file and pipe it to the response
    const stream = fs.createReadStream(filePath);
    stream.on('error', (err) => {
      console.error(err);
      res.status(500).send('Internal Server Error');
    });
    stream.pipe(res);
  });
});

const port = 5450;
app.listen(port, () => console.log(`Music streaming server listening on port ${port}`));
