const express = require('express');
const http = require('http');
const socketIO = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = socketIO(server);

const port = 5900;

io.on("connection", function (socket) {
    console.log("User Connected");

    socket.on('join room', (code) => {
        socket.join(code);
    });

    socket.on("mess", ({ room, mess }) => {
        socket.to(room).emit("mess", {
            mess,
        });
    });

    socket.on('disconnect', () => {
        console.log('User Disconnected');
    });
});

server.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
